var express = require('express');
var router = express.Router();
var pg = require('pg');

/* add page. */
router.post('/', function(request, response, next) {
    var name_str = request.body["name"];
    var mail_str = request.body["mail"];
    var memo_str = request.body["memo"];

    var con = "tcp://postgres:tatsuya1996@localhost:5432/java_postgre";
    pg.connect(con, function(err, client) {
        var qstr = "insert into mydata (name,mail,memo) values($1, $2, $3);";
        var query = client.query(qstr,[name_str, mail_str, memo_str]);
        query.on('end', function(row,err) {
            response.redirect("/");
        });
        query.on('error', function(error) {
            console.log("ERROR!");
            response.render('index', {
                title: "ERROR",
                data: null,
                message: "ERROR is occured!"
            });
        });
    });
});

module.exports = router;
