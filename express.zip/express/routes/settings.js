exports.pgdb = "tcp://postgres:tatsuya1996@localhost:5432/java_postgre";
