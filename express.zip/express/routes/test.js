//検索用のソース
var express = require('express');
var router = express.Router();

// postgresqlモジュール読み込み
var pg = require('pg');

// 外部ファイルの読み込み(自作のときはパスを指定する。拡張子は省略可)
// exportsを使っているので参照することができる
var settings = require('./settings');
var connectionString = settings.pgdb;

// localhost:3000/ でアクセスされたときのルーティング処理
// なので/userとか書けば、localhost:3000/userでアクセスしたときの処理となる。
router.get('/', function(req, res) {
  // postgresqlの処理
  pg.connect(connectionString, function(err, client){
    client.query("SELECT id, name FROM test ", function(err, result){
      // ejs に対する処理
      res.render('index', {
         title : "ユーザー情報取得",
         result : result,
         data : result.rows.length
      });
    });
  });
});
