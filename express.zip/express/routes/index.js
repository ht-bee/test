
var express = require('express');
var router = express.Router();
var pg = require('pg');


/* GET home page. */
/*router.get('/', function(request, response, next) {
    var con = "tcp://postgres:tatsuya1996@localhost:5432/java_postgre"; //★
    pg.connect(con, function(err, client) {
        var query = client.query('select * from mydata;');
        var rows = [];
        query.on('row', function(row) {
            rows.push(row);
        });
        query.on('end', function(row,err) {
            response.render('index', {
                title: 'Express',
                data:rows
            });
        });
        query.on('error', function(error) {
            console.log("ERROR!!" + error);
            response.render('index', {
                title: title,
                data: null,
                message: "ERROR is occured!"
            });
        });
    });
});

module.exports = router;
*/

router.get('/', function(request, response, next) {
    var con = "tcp://postgres:tatsuya1996@localhost:5432/java_postgre"; //★
    pg.connect(con, function(err, client) {
      //  var query = client.query('SELECT game_name, game_CPU, game_Memory, game_MB, game_GPU FROM game ;');
      //  var rows = [];
    //    query.on('row', function(row) {
        //    rows.push(row);
      //  });
      //query.on('end', function(row,err) {
    //response.render('index', {
      //  title: 'Express',
    //    data:rows
  //  });
//});
        client.query('SELECT game_name, game_CPU, game_Memory, game_MB, game_GPU FROM game', function(err,result) {
            response.render('index', {
                title1: "express",
                title2: "ぱそこん検索",
                result : result,
                data : result.rows.length,
                name : result.rows[0].game_name
            });
        });
        /*query.on('error', function(error) {
            console.log("ERROR!!" + error);
            response.render('index', {
                title: title,
                data: null,
                message: "ERROR is occured!"
            });
        });*/
    });
});

module.exports = router;
